import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'

/**
 * Utilidad estándar de cuicui.day (idéntica a la de shadcn/ui): combina
 * clsx + tailwind-merge para poder pasar clases condicionales sin que
 * choquen utilidades de Tailwind repetidas (ej. dos `px-*` distintos).
 *
 * Los componentes copiados desde cuicui.day (ver src/components/ui/SearchBar.tsx)
 * importan esto desde "@/cuicui/utils/cn" — se replica esa misma ruta acá
 * para no tener que tocar el código pegado del sitio.
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}
