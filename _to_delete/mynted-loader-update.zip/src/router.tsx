import { createRootRoute, createRoute, createRouter } from '@tanstack/react-router'
import App from './App'
import { Loader } from './components/ui/Loader'
import HomePage from './pages/HomePage'
import LoginPage from './pages/LoginPage'

/**
 * Configuración de rutas del frontend.
 *
 * Por ahora solo existen dos pantallas:
 * - "/"      -> pantalla base vacía (home), lista para irse llenando
 *               a medida que avancen los demás módulos.
 * - "/login" -> tarjeta de autenticación (login / crear cuenta),
 *               ya conectada del lado del frontend y esperando los
 *               endpoints reales del backend (ver src/features/auth/api.ts).
 *
 * Cuando se agreguen más pantallas (comunidades, marketplace, foro, etc.)
 * solo hace falta crear su página en src/pages y registrar una nueva
 * createRoute() aquí.
 */
const rootRoute = createRootRoute({
  component: App,
})

const homeRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/',
  component: HomePage,
})

const loginRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/login',
  component: LoginPage,
})

const routeTree = rootRoute.addChildren([homeRoute, loginRoute])

export const router = createRouter({
  routeTree,
  // Loader oficial de la app (el gansito) mientras se resuelve la
  // navegación entre rutas o la carga de datos de una ruta.
  defaultPendingComponent: () => (
    <div className="flex min-h-svh items-center justify-center bg-mynted-bg">
      <Loader label="Cargando…" size={120} />
    </div>
  ),
})

declare module '@tanstack/react-router' {
  interface Register {
    router: typeof router
  }
}
