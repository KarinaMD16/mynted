import type { FC } from 'react'
import { Link, useRouterState } from '@tanstack/react-router'
import { Bell01, ChevronDown, LogOut01, SearchLg, Settings01, User01 } from '@untitledui/icons'
import { Button as AriaButton, Dialog as AriaDialog, DialogTrigger as AriaDialogTrigger, Popover as AriaPopover } from 'react-aria-components'
import { GooseIcon } from '../ui/GooseIcon'

/**
 * Header oficial de la app, integrado a partir del componente
 * `header-navigation` de Untitled UI (ver src/components/application/
 * app-navigation/) y reajustado a mano para calzar con el mockup de
 * Figma (archivo "mynted", nodo 199:4529 "Header"): logo + wordmark,
 * nav pill activo en naranja, buscador amarillo, campana de
 * notificaciones y pill de cuenta — ambas con su propio dropdown.
 */
const NAV_ITEMS: { label: string; href: '/' | '/explore' | '/communities' | '/favorites' | '/messages' }[] = [
  { label: 'Home', href: '/' },
  { label: 'Explore', href: '/explore' },
  { label: 'Communities', href: '/communities' },
  { label: 'Favorites', href: '/favorites' },
  { label: 'Messages', href: '/messages' },
]

const navItemBaseClass =
  'rounded-[10px] px-4 py-[9px] text-[15px] font-medium whitespace-nowrap text-mynted-gray transition-colors hover:bg-mynted-orange hover:text-mynted-white'

// Animación compartida de entrada/salida de los popovers del header
// (react-aria-components + tailwindcss-animate, mismo patrón que usa
// Untitled UI en su propio NavAccountCard).
const popoverAnimationClass = ({ isEntering, isExiting }: { isEntering: boolean; isExiting: boolean }) =>
  [
    'w-max origin-top-right will-change-transform',
    isEntering && 'duration-150 ease-out animate-in fade-in slide-in-from-top-1',
    isExiting && 'duration-100 ease-in animate-out fade-out slide-out-to-top-1',
  ]
    .filter(Boolean)
    .join(' ')

interface SiteHeaderProps {
  /** Nombre mostrado en la pill de cuenta (esquina superior derecha). */
  userName?: string
}

export function SiteHeader({ userName = 'Karina' }: SiteHeaderProps) {
  const pathname = useRouterState({ select: (state) => state.location.pathname })

  return (
    <header className="mx-auto flex w-full max-w-[1320px] flex-wrap items-center justify-between gap-4 rounded-2xl border border-mynted-border bg-mynted-white px-6 py-4 sm:flex-nowrap sm:px-12 sm:py-[18px]">
      <Link to="/" className="flex shrink-0 items-center gap-2.5 rounded-xs outline-focus-ring focus-visible:outline-2 focus-visible:outline-offset-2">
        <GooseIcon className="size-9 shrink-0 text-mynted-orange" />
        <span className="font-heading text-[22px] font-semibold text-mynted-blue-mid">mynted</span>
      </Link>

      <nav className="order-3 w-full lg:order-none lg:w-auto">
        <ul className="flex flex-wrap items-center gap-1.5">
          {NAV_ITEMS.map((item) => {
            const isActive = pathname === item.href
            return (
              <li key={item.href}>
                <Link
                  to={item.href}
                  className={`${navItemBaseClass} ${isActive ? 'bg-mynted-orange font-semibold text-mynted-white' : ''}`}
                >
                  {item.label}
                </Link>
              </li>
            )
          })}
        </ul>
      </nav>

      <div className="flex shrink-0 items-center gap-3.5">
        <label className="hidden items-center gap-2 rounded-[10px] bg-mynted-yellow px-4 py-2.5 sm:flex">
          <SearchLg className="size-[18px] shrink-0 text-mynted-ink" aria-hidden="true" />
          <input
            type="search"
            placeholder="Buscar comunidades..."
            className="w-36 bg-transparent text-sm text-mynted-ink placeholder:text-mynted-ink/70 focus:outline-none md:w-44"
          />
        </label>

        <NotificationsMenu />
        <AccountMenu userName={userName} />
      </div>
    </header>
  )
}

/** Campana de notificaciones con su propio dropdown (todavía sin datos reales del backend). */
function NotificationsMenu() {
  return (
    <AriaDialogTrigger>
      <AriaButton
        aria-label="Notificaciones"
        className="flex size-10 shrink-0 cursor-pointer items-center justify-center rounded-full border border-mynted-border bg-mynted-blue-mid text-mynted-white outline-none transition-opacity hover:opacity-90 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-mynted-blue-mid pressed:opacity-80"
      >
        <Bell01 className="size-[22px]" aria-hidden="true" />
      </AriaButton>

      <AriaPopover placement="bottom right" offset={8} className={popoverAnimationClass}>
        <AriaDialog className="w-72 rounded-xl border border-mynted-border bg-mynted-white p-4 shadow-lg outline-none">
          <p className="text-sm font-semibold text-mynted-ink">Notificaciones</p>
          {/* TODO(backend): reemplazar por el feed real de notificaciones cuando exista el endpoint. */}
          <p className="mt-2 text-sm text-mynted-gray">
            Todavía no tenés notificaciones. Acá vas a ver actividad de tus comunidades, intercambios y mensajes.
          </p>
        </AriaDialog>
      </AriaPopover>
    </AriaDialogTrigger>
  )
}

/** Pill de cuenta con su propio dropdown (perfil / configuración / cerrar sesión). */
function AccountMenu({ userName }: { userName: string }) {
  return (
    <AriaDialogTrigger>
      <AriaButton className="flex shrink-0 cursor-pointer items-center gap-1.5 rounded-full border border-mynted-border bg-mynted-orange py-1.5 pr-3.5 pl-1.5 outline-none transition-colors hover:bg-mynted-orange-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-mynted-blue-mid pressed:bg-mynted-orange-hover">
        <span className="flex size-[30px] shrink-0 items-center justify-center rounded-full bg-mynted-white/25">
          <GooseIcon className="size-[22px] text-mynted-white" />
        </span>
        <span className="text-sm font-semibold whitespace-nowrap text-mynted-white">{userName}</span>
        <ChevronDown className="size-3.5 shrink-0 text-mynted-white/80" aria-hidden="true" />
      </AriaButton>

      <AriaPopover placement="bottom right" offset={8} className={popoverAnimationClass}>
        <AriaDialog className="w-56 rounded-xl border border-mynted-border bg-mynted-white p-1.5 shadow-lg outline-none">
          {/* TODO(backend): wirear estas acciones (perfil, configuración, logout) cuando exista el endpoint de auth. */}
          <MenuItem icon={User01} label="Mi perfil" />
          <MenuItem icon={Settings01} label="Configuración" />
          <div className="my-1 border-t border-mynted-border" />
          <MenuItem icon={LogOut01} label="Cerrar sesión" tone="danger" />
        </AriaDialog>
      </AriaPopover>
    </AriaDialogTrigger>
  )
}

function MenuItem({ icon: Icon, label, tone = 'default' }: { icon: FC<{ className?: string }>; label: string; tone?: 'default' | 'danger' }) {
  return (
    <button
      type="button"
      className={`flex w-full cursor-pointer items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-sm font-medium transition-colors outline-none hover:bg-mynted-bg focus-visible:bg-mynted-bg ${
        tone === 'danger' ? 'text-red-600' : 'text-mynted-ink'
      }`}
    >
      <Icon className="size-[18px] shrink-0" aria-hidden="true" />
      {label}
    </button>
  )
}
