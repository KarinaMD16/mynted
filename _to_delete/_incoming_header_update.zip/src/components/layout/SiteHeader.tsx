import { Link, useRouterState } from '@tanstack/react-router'
import { Bell01, SearchLg } from '@untitledui/icons'
import { GooseIcon } from '../ui/GooseIcon'

/**
 * Header oficial de la app, integrado a partir del componente
 * `header-navigation` de Untitled UI (ver src/components/application/
 * app-navigation/) y reajustado a mano para calzar con el mockup de
 * Figma (archivo "mynted", nodo 199:4529 "Header"): logo + wordmark,
 * nav pill activo en naranja, buscador amarillo, campana de
 * notificaciones y pill de cuenta.
 *
 * TODO(routes): Explore, Communities, Favorites y Messages todavía no
 * tienen pantallas propias — apuntan a "#" hasta que se creen esas
 * rutas. Solo "Home" navega de verdad por ahora.
 */
const NAV_ITEMS: { label: string; href: string }[] = [
  { label: 'Home', href: '/' },
  { label: 'Explore', href: '#' },
  { label: 'Communities', href: '#' },
  { label: 'Favorites', href: '#' },
  { label: 'Messages', href: '#' },
]

const navItemBaseClass = 'rounded-[10px] px-4 py-[9px] text-[15px] whitespace-nowrap transition-colors'

interface SiteHeaderProps {
  /** Nombre mostrado en la pill de cuenta (esquina superior derecha). */
  userName?: string
}

export function SiteHeader({ userName = 'Karina' }: SiteHeaderProps) {
  const pathname = useRouterState({ select: (state) => state.location.pathname })

  return (
    <header className="mx-auto flex w-full max-w-[1320px] flex-wrap items-center justify-between gap-4 rounded-2xl border border-mynted-border bg-mynted-white px-6 py-4 sm:flex-nowrap sm:px-12 sm:py-[18px]">
      <Link to="/" className="flex shrink-0 items-center gap-2.5 rounded-xs outline-focus-ring focus-visible:outline-2 focus-visible:outline-offset-2">
        <GooseIcon className="size-9 shrink-0 text-mynted-orange" />
        <span className="font-heading text-[22px] font-semibold text-mynted-blue-mid">mynted</span>
      </Link>

      <nav className="order-3 w-full lg:order-none lg:w-auto">
        <ul className="flex flex-wrap items-center gap-1.5">
          {NAV_ITEMS.map((item) => {
            const isActive = item.href === '/' && pathname === '/'
            return (
              <li key={item.label}>
                {item.href === '/' ? (
                  <Link
                    to={item.href}
                    className={`${navItemBaseClass} ${
                      isActive ? 'bg-mynted-orange font-semibold text-mynted-white' : 'font-medium text-mynted-gray hover:text-mynted-ink'
                    }`}
                  >
                    {item.label}
                  </Link>
                ) : (
                  <a href={item.href} className={`${navItemBaseClass} font-medium text-mynted-gray hover:text-mynted-ink`}>
                    {item.label}
                  </a>
                )}
              </li>
            )
          })}
        </ul>
      </nav>

      <div className="flex shrink-0 items-center gap-3.5">
        <label className="hidden items-center gap-2 rounded-[10px] bg-mynted-yellow px-4 py-2.5 sm:flex">
          <SearchLg className="size-[18px] shrink-0 text-mynted-ink" aria-hidden="true" />
          <input
            type="search"
            placeholder="Buscar comunidades..."
            className="w-36 bg-transparent text-sm text-mynted-ink placeholder:text-mynted-ink/70 focus:outline-none md:w-44"
          />
        </label>

        <button
          type="button"
          aria-label="Notificaciones"
          className="flex size-10 shrink-0 items-center justify-center rounded-full border border-mynted-border bg-mynted-blue-mid text-mynted-white transition-opacity hover:opacity-90 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-mynted-blue-mid"
        >
          <Bell01 className="size-[22px]" aria-hidden="true" />
        </button>

        <div className="flex shrink-0 items-center gap-2 rounded-full border border-mynted-border bg-mynted-orange py-1.5 pr-4 pl-1.5">
          <span className="flex size-[30px] shrink-0 items-center justify-center rounded-full bg-mynted-white/25">
            <GooseIcon className="size-[22px] text-mynted-white" />
          </span>
          <span className="text-sm font-semibold whitespace-nowrap text-mynted-white">{userName}</span>
        </div>
      </div>
    </header>
  )
}
