import { Link } from '@tanstack/react-router'
import { SiteHeader } from '../components/layout/SiteHeader'
import { Logo } from '../components/ui/Logo'

/**
 * Pantalla base de la app ("/"), todavía vacía a propósito.
 *
 * Ya incluye el header oficial (ver src/components/layout/SiteHeader.tsx).
 * El resto del contenido (accesos a Marketplace/Foro, feed
 * personalizado, buscador, comunidades destacadas, etc. — ver el
 * módulo "Página principal" en la documentación del proyecto) se
 * agrega en un próximo paso.
 */
export default function HomePage() {
  return (
    <div className="min-h-svh bg-mynted-bg">
      <div className="px-4 pt-5 sm:px-6">
        <SiteHeader />
      </div>

      <main className="flex flex-col items-center justify-center gap-4 px-4 py-24 text-center">
        <Logo className="text-[40px]" />
        <p className="max-w-sm text-sm text-mynted-gray">
          Pantalla base en construcción. El contenido de la página principal se agrega en un próximo paso.
        </p>
        <Link
          to="/login"
          className="mt-2 rounded-[10px] bg-mynted-orange px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-mynted-orange-hover"
        >
          Ir a Login
        </Link>
      </main>
    </div>
  )
}
